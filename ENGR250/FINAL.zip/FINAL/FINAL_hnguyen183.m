% Hai H Nguyen
% Philip Andrist
% 3/20/2015
% Version Winter 2015

close all;
clearvars;
clc

set1();

set2();

% #Responds at the end of set2#