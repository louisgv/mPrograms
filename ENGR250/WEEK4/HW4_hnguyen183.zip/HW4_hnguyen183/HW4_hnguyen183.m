% Hai H Nguyen
% Philip Andrist
% 2/24/2015
% Version Winter 2015

close all;
% clearvars;
clc

set1();

set2();

set3();

set4();
